Irish Sunburst Flag (v1.0.0)

Copyright (c) Keith Gaughan, 2002-2022.
http://keith.gaughan.ie/
keith@gaughan.ie

The Sunburst is a poetic flag sometimes used in Ireland and
supposedly the standard used by the Fianna. I adopted it as
the flag of an alternate version of Ireland called 'An
tAonsdát Éireann' as part of a collaborative conculture
project called Ill Bethisad.

Permission is given to use, distribute, and create derivative
works on condition credit for original authorship is clearly
supplied with derived works and works that include the
original.
