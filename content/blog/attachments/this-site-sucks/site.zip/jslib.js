/*
 * Copyright (c) Keith Gaughan, 2004.
 * All Rights Reserved.
 *
 * Permission is expressly granted to copy and reuse this code or any functions
 * contained herein freely provided that the following conditions are met:
 *
 *    i. This copyright notice MUST be retained. And no, if you remove it
 *       under the guise of trying to save some download time, then you're
 *       infringing my copyright, buddy. Deal with it. Clip out functions you
 *       don't need, but this stays.
 *   ii. Any modifications to this code must be identified as such, and include
 *       a note specifying the modifier, and how it was modified. I don't want
 *       to get the blame for someone else's screwups.
 *  iii. You recognise that in modifying this code, the copyright on any
 *       modified version of this code is mine. That's the law, so don't go
 *       modifying it and plastering your own copyright on it.
 *   iv. If something goes wrong and it's directly or indirectly due to this
 *       code, don't blame me: NO WARRANTIES. Mind you, my pride prevents me
 *       from willingly spreading shoddy code, so this should never be an
 *       issue.
 *    v. You can freely link this code to another system, but as my copyright
 *       still exists, this copyright notice MUST be included in your program
 *       documentation, and where any credit is given, the statement, "This
 *       program includes software under licence from Keith Gaughan". That
 *       said, this cannot be used for promotional purposes (not that I'm
 *       famous enough for this to ever matter).
 *
 * You can get things right if you adhere to the converse of the golden rule:
 * if our positions were reversed, would you like it if I screwed with you? I
 * think not, so don't.
 */

if (!Array.prototype.push) {
	Array.prototype.push = function() {
		for (var i = 0; i < arguments.length; ++i) {
			this[this.length] = arguments[i];
		}
	}
}

/**
 * Adds an event handler to the event handler list for a given even on a given
 * object in a portable and clean manner. This is better and cleaner than
 * using HTML attributes.
 */
function AddEvent(obj, type, fn) {
	// Mozilla/W3C listeners?
	if (obj.addEventListener) {
		obj.addEventListener(type, fn, false);
		return true;
	}

	// IE-style listeners?
	if (obj.attachEvent) {
		return obj.attachEvent('on' + type, fn);
	}

	return false;
}

/**
 *
 */
function ExtractBlockquoteCitations() {
	if (!document.createElement) {
		return;
	}

	// For each block quote...
	var quotes = document.getElementsByTagName('blockquote');
	for (var i = 0; i < quotes.length; i++) {
		// ...that includes a citation...
		var cite = quotes[i].getAttribute('cite');
		if (cite != '' && cite != null) {
			// Create a link to the cited resource...
			var a = document.createElement('a');
			a.setAttribute('href', cite);

			var titleNode;
			var title = quotes[i].getAttribute('title');
			if (title == '' || title == null) {
				a.setAttribute('title', cite);
				titleNode = document.createTextNode('Source');
			} else {
				a.setAttribute('title', title);
				titleNode = document.createTextNode(title);
			}
			a.appendChild(titleNode);

			// ...wrap it in a paragraph with class 'source',...
			var p = document.createElement('p');
			p.className = 'source';
			p.appendChild(a);

			// ...and put it at the end of the blockquote.
			quotes[i].appendChild(p);
		}
	}
}

// Apply float clearing fix when page loads in IE5/Mac.
AddEvent(window, 'load', function() {
	// Check if the browser is IE5/Mac
	if (navigator.appVersion.indexOf('Mac') != -1 && document.all) {
		var divs = document.getElementsByTagName('div');
		for (var i = 0; i < divs.length; i++) {
			if (divs[i].className.indexOf('clearfix') >= 0) {
				divs[d].innerHTML +=
					'<div style="clear:both;overflow:hidden;height:0">&nbsp;</div>';
			}
		}
	}
});

// Set up a closure that executes a bunch of initialiser on load. Feel free to
// modify this bit without danger of being zapped by my death-rays... ;-)
AddEvent(window, 'load', ExtractBlockquoteCitations);
